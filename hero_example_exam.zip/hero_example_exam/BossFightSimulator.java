import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

public class BossFightSimulator {

    private static final Random randomGenerator = new Random();
    private static final List<GameCharacter> heroes = Collections.synchronizedList(new ArrayList<>());
    private static final AtomicBoolean isOver = new AtomicBoolean(false);

    public static void main(String[] args) {
        startGame();
    }

    public static void startGame() {
        Boss boss = new Boss();
        heroes.add(new HealerHero());
        heroes.add(new AttackingHero("Attacker1"));
        heroes.add(new AttackingHero("Attacker2"));
        heroes.add(new AttackingHero("Attacker3"));
        heroes.add(new AttackingHero("Attacker4"));

        List<Thread> threads = new ArrayList<>();
        threads.add(new Thread(() -> {
            bossBehaviour(boss);
        }));
        for (GameCharacter hero : heroes) {
            if (hero instanceof HealerHero)
                threads.add(new Thread(() -> healerBehaviour((HealerHero) hero)));
            else
                threads.add(new Thread(() -> attackerBehaviour((AttackingHero) hero, boss)));
        }

        threads.forEach(Thread::start);
        threads.forEach(t -> {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

    }

    private static void bossBehaviour(Boss boss) {
        while (!boss.isDead() && !isOver.get()) {
            if (!heroes.isEmpty()) {
                GameCharacter hero = heroes.get(getRandomNumber(0, heroes.size()));
                int value = getRandomNumber(boss.getDamageThresholdLower(), boss.getDamageThresholdUpper());
                boss.performAction(hero, value);
            }
            int waitTime = getRandomNumber(600, 1200);
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (boss.getHealth() <= 0) {
            isOver.set(true);
            System.out.println(boss.getName() + " has died - heroes won!");
            heroes.forEach(h -> System.out.println(h.getName() + " survived with " + h.getHealth() + " health"));
        } else {
            System.out.println(boss.getName() + " killed everyone, he won!");
        }
    }

    public static void attackerBehaviour(AttackingHero attacker, Boss boss) {
        while (!attacker.isDead() && !isOver.get()) {
            int value = getRandomNumber(attacker.getDamageThresholdLower(), attacker.getDamageThresholdUpper());
            attacker.performAction(boss, value);
            int waitTime = getRandomNumber(1300, 1500);
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        handleHeroDeath(attacker);
    }

    public static void healerBehaviour(HealerHero healer) {
        while (!healer.isDead() && !isOver.get()) {
            int value = getRandomNumber(healer.getDamageThresholdLower(), healer.getDamageThresholdUpper());
            GameCharacter lowestHealthHero = heroes.get(0);
            for (GameCharacter hero : heroes) {
                if (hero.getHealth() < lowestHealthHero.getHealth()) {
                    lowestHealthHero = hero;
                }
            }
            healer.performAction(lowestHealthHero, value);
            int waitTime = getRandomNumber(1500, 2000);
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        handleHeroDeath(healer);
    }

    private static void handleHeroDeath(GameCharacter hero) {
        if (hero.isDead()) {
            heroes.remove(hero);
            System.out.println(hero.getName() + " has died!");
            if (heroes.isEmpty()) {
                isOver.set(true);
            }
        }
    }

    private static synchronized int getRandomNumber(int lower, int upper) {
        int bound = upper - lower;
        if (bound == 0)
            return 0;
        return lower + Math.abs(randomGenerator.nextInt() % bound);
    }
}
