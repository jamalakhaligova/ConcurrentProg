public class HealerHero extends GameCharacter {

    public HealerHero() {
        super(100, 25, 35, "Healer");
    }

    @Override
    public void performAction(GameCharacter target, int value) {
        target.addHealth(value);
        System.out.println(name + " healed " + target.getName() + " for " + value);
    }
}
