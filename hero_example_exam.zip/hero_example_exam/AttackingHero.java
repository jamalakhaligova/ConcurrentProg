public class AttackingHero extends GameCharacter {

    public AttackingHero(String name) {
        super(110, 5, 10, name);
    }

    @Override
    public void performAction(GameCharacter target, int value) {
        target.removeHealth(value);
        System.out.println(name + " damaged " + target.getName() + " for " + value);
    }
}
