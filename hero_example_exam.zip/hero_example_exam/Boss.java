public class Boss extends GameCharacter {

    public Boss() {
        super(300, 30, 45, "Boss");
    }

    @Override
    public void performAction(GameCharacter target, int value) {
        target.removeHealth(value);
        System.out.println(name + " damaged " + target.getName() + " for " + value);
    }
}
