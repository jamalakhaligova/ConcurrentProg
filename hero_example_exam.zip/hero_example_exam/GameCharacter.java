import java.util.concurrent.atomic.AtomicInteger;

public abstract class GameCharacter {

    protected final AtomicInteger health;
    protected final int maxHealth;
    protected final int damageThresholdLower;
    protected final int damageThresholdUpper;
    protected final String name;

    public GameCharacter(int health, int damageThresholdLower, int damageThresholdUpper, String name) {
        this.maxHealth = health;
        this.health = new AtomicInteger(health);
        this.damageThresholdLower = damageThresholdLower;
        this.damageThresholdUpper = damageThresholdUpper;
        this.name = name;
    }

    public abstract void performAction(GameCharacter target, int value);

    public int getDamageThresholdLower() {
        return this.damageThresholdLower;
    }

    public int getDamageThresholdUpper() {
        return this.damageThresholdUpper;
    }

    public void addHealth(int value) {
        if (!isDead()) {
            health.getAndUpdate(prev -> Math.min(prev + value, maxHealth));
        }
    }

    public void removeHealth(int value) {
        if (!isDead()) {
            health.addAndGet(-value);
        }
    }

    public int getHealth() {
        return this.health.get();
    }

    public boolean isDead() {
        return this.health.get() <= 0;
    }

    public String getName() {
        return this.name;
    }
}
